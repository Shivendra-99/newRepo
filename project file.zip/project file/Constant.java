/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.blog.util;

/**
 *
 * @author 1460344
 */
public class Constants {
    
    public static String JWT_SECRET="MY_BLOG_SECRET";
}
